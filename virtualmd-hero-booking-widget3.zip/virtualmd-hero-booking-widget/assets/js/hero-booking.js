  document.addEventListener('DOMContentLoaded', function () {
    var VMHB_CONFIG = window.VMHB_CONFIG || {};
    var VM_AJAX_URL = VMHB_CONFIG.ajaxUrl || '/wp-admin/admin-ajax.php';
    var VMHB_ACTIONS = VMHB_CONFIG.actions || {};
    function vmhbAction(name, fallback) { return VMHB_ACTIONS[name] || fallback; }

    // --- Stripe Return Handler ---
    // Si el usuario retorna de Stripe checkout (return_url), verificar pago
    var urlParams = new URLSearchParams(window.location.search);
    if (urlParams.get('stripe_return') === '1' && urlParams.get('session_id')) {
      var returnSessionId = urlParams.get('session_id');
      var verifyUrl = VM_AJAX_URL + (VM_AJAX_URL.indexOf('?') !== -1 ? '&' : '?') + 'action=' + vmhbAction('stripeVerifyPayment', 'vm_stripe_verify_payment');

      // Mostrar el stage de success directamente
      var bStage = document.getElementById('vmSpeedHeroBookingStage');
      var sStage = document.getElementById('vmSpeedHeroSuccessStage');
      if (bStage && sStage) {
        bStage.classList.add('is-hidden');
        bStage.setAttribute('aria-hidden', 'true');
        sStage.classList.add('is-active');
        sStage.setAttribute('aria-hidden', 'false');
      }

      // Verificar y crear cita en segundo plano
      fetch(verifyUrl, {
        method: 'POST',
        body: JSON.stringify({ session_id: returnSessionId }),
        headers: { 'Content-Type': 'application/json' }
      })
        .then(function (res) { return res.json(); })
        .then(function (res) {
          if (res.success && res.data && res.data.status === 'complete') {
            console.log('[VM Stripe] Pago verificado exitosamente desde return URL');
          } else {
            console.warn('[VM Stripe] Estado de pago:', res);
          }
        })
        .catch(function (err) {
          console.error('[VM Stripe] Error al verificar pago:', err);
        });

      // Limpiar URL para evitar re-verificaciones
      if (window.history && window.history.replaceState) {
        var cleanUrl = window.location.pathname;
        window.history.replaceState({}, document.title, cleanUrl);
      }

      return; // No inicializar el widget normal si estamos en return mode
    }

    var bookingWidget = document.getElementById('vmSpeedBookingWidget');
    var doctorModeButtons = document.querySelectorAll('.vm-speed-doctor-mode');
    var heroShell = document.querySelector('.vm-speed-hero-shell');
    var heroStages = document.getElementById('vmSpeedHeroStages');
    var bookingStage = document.getElementById('vmSpeedHeroBookingStage');
    var formStage = document.getElementById('vmSpeedHeroFormStage');
    var successStage = document.getElementById('vmSpeedHeroSuccessStage');
    var backToBookingBtn = document.getElementById('vmSpeedBackToBooking');
    var intakeSummary = document.getElementById('vmSpeedIntakeSummary');
    var submitBookingBtn = document.getElementById('vmSpeedSubmitBooking');


    // Payment stage elements (Stripe)
    var paymentStage = document.getElementById('vmSpeedHeroPaymentStage');
    var backToFormBtn = document.getElementById('vmSpeedBackToForm');
    var stripeCheckoutEl = document.getElementById('vmStripeCheckout');
    var stripeLoadingEl = document.getElementById('vmStripeLoading');
    var stripeErrorEl = document.getElementById('vmStripeError');
    var stripeRetryBtn = document.getElementById('vmStripeRetryBtn');
    var paymentSumService = document.getElementById('vmPaymentSummaryService');
    var paymentSumDate = document.getElementById('vmPaymentSummaryDate');
    var paymentSumTotal = document.getElementById('vmPaymentSummaryTotal');

    // Stripe state
    var stripeInstance = null;
    var stripeCheckoutInstance = null;
    var currentSessionId = null;
    var pendingBookingPayload = null;

    var intakeName = document.getElementById('vmSpeedIntakeName');
    var intakePhoneCountry = document.getElementById('vmSpeedIntakePhoneCountry');
    var intakePhone = document.getElementById('vmSpeedIntakePhone');
    var intakeEmail = document.getElementById('vmSpeedIntakeEmail');
    var intakeCity = document.getElementById('vmSpeedIntakeCity');
    var intakeMessage = document.getElementById('vmSpeedIntakeMessage');

    var specialtyField = document.getElementById('vmSpeedSpecialtyField');
    var specialtyToggle = document.getElementById('vmSpeedSpecialtyToggle');
    var specialtyPopover = document.getElementById('vmSpeedSpecialtyPopover');
    var specialtyValue = document.getElementById('vmSpeedSpecialtyValue');
    var categoryList = document.getElementById('vmSpeedCategoryList');
    var serviceList = document.getElementById('vmSpeedServiceList');
    var specialtyGridEl = document.querySelector('.vm-speed-specialty-grid');

    function isMobileView() {
      return window.innerWidth <= 680;
    }

    function getSelectedPhoneCountry() {
      var option = intakePhoneCountry && intakePhoneCountry.options
        ? intakePhoneCountry.options[intakePhoneCountry.selectedIndex]
        : null;

      return {
        iso: option ? option.value : 'mx',
        dialCode: option && option.dataset && Object.prototype.hasOwnProperty.call(option.dataset, 'dial')
          ? option.dataset.dial
          : '+52'
      };
    }

    function normalizePhoneForBooking(rawPhone, phoneCountry) {
      var raw = (rawPhone || '').trim();
      var digits = raw.replace(/\D+/g, '');
      var dialDigits = (phoneCountry.dialCode || '').replace(/\D+/g, '');

      if (!digits) {
        return '';
      }

      if (raw.indexOf('+') === 0) {
        return '+' + digits;
      }

      if (digits.indexOf('00') === 0 && digits.length > 4) {
        return '+' + digits.slice(2);
      }

      if (dialDigits && digits.indexOf(dialDigits) === 0 && digits.length > dialDigits.length + 4) {
        return '+' + digits;
      }

      return '+' + dialDigits + digits;
    }

    function getLocalPhoneDigits(rawPhone, phoneCountry, formattedPhone) {
      var rawDigits = (rawPhone || '').replace(/\D+/g, '');
      var formattedDigits = (formattedPhone || '').replace(/\D+/g, '');
      var dialDigits = (phoneCountry.dialCode || '').replace(/\D+/g, '');

      if (dialDigits && formattedDigits.indexOf(dialDigits) === 0) {
        return formattedDigits.slice(dialDigits.length);
      }

      return rawDigits;
    }

    function isPhoneValidForCountry(rawPhone, phoneCountry, formattedPhone) {
      var localDigits = getLocalPhoneDigits(rawPhone, phoneCountry, formattedPhone);

      if (phoneCountry.iso === 'mx' || phoneCountry.iso === 'us' || phoneCountry.iso === 'ca') {
        return localDigits.length === 10;
      }

      return localDigits.length >= 6 && localDigits.length <= 14;
    }

    function updatePhonePlaceholder() {
      if (!intakePhone || !intakePhoneCountry) return;

      var country = getSelectedPhoneCountry();
      intakePhone.placeholder = !country.dialCode
        ? 'Incluye + lada'
        : (country.iso === 'mx' || country.iso === 'us' || country.iso === 'ca')
        ? '10 dígitos'
        : 'Número local';
    }

    if (intakePhoneCountry) {
      intakePhoneCountry.addEventListener('change', updatePhonePlaceholder);
      updatePhonePlaceholder();
    }

    function showMobileServices() {
      if (specialtyGridEl) specialtyGridEl.classList.add('is-showing-services');
    }

    function showMobileCategories() {
      if (specialtyGridEl) specialtyGridEl.classList.remove('is-showing-services');
    }

    var doctorField = document.getElementById('vmSpeedDoctorField');
    var doctorToggle = document.getElementById('vmSpeedDoctorToggle');
    var doctorPopover = document.getElementById('vmSpeedDoctorPopover');
    var doctorValue = document.getElementById('vmSpeedDoctorValue');
    var doctorList = document.getElementById('vmSpeedDoctorList');

    var dateField = document.getElementById('vmSpeedDateField');
    var dateToggle = document.getElementById('vmSpeedDateToggle');
    var datePopover = document.getElementById('vmSpeedDatePopover');
    var dateValue = document.getElementById('vmSpeedDateValue');
    var calTitle = document.getElementById('vmSpeedCalTitle');
    var calDays = document.getElementById('vmSpeedCalDays');
    var calPrev = document.getElementById('vmSpeedCalPrev');
    var calNext = document.getElementById('vmSpeedCalNext');
    var weekdays = document.getElementById('vmSpeedWeekdays');
    var timeList = document.getElementById('vmSpeedTimeList');
    var bookingCta = document.getElementById('vmSpeedBookingCta');
    var specialtySearch = document.getElementById('vmSpeedSpecialtySearch');
    var doctorSearch = document.getElementById('vmSpeedDoctorSearch');

    if (!bookingWidget || !specialtyField || !dateField || !specialtyToggle || !dateToggle || !bookingCta) {
      return;
    }

    // --- Datos dinámicos (se cargan desde API de Amelia) ---
    var specialtyData = [];
    var doctorData = [];
    var slotsData = {};         // { "2026-03-10": ["09:00","10:00",...], ... } (free)
    var occupiedData = {};      // { "2026-03-10": ["07:00","08:00",...], ... } (taken)
    var providerMapData = {};   // auto mode: { "2026-03-10": { "09:00": [3,5], ... } }
    var slotsPayloadLoaded = false;
    var isLoadingCatalog = false;
    var isLoadingDoctors = false;
    var isLoadingSlots = false;
    var doctorCacheByService = {};
    var slotsCacheByQuery = {};
    var activeDoctorsRequestId = 0;
    var activeSlotsRequestId = 0;
    var slotsAbortController = null;
    var supportsAbortController = typeof AbortController !== 'undefined';

    var weekLabels = ['Lu', 'Ma', 'Mi', 'Ju', 'Vi', 'Sa', 'Do'];
    var monthFormatter = new Intl.DateTimeFormat('es-MX', { month: 'long', year: 'numeric' });
    var shortDateFormatter = new Intl.DateTimeFormat('es-MX', { weekday: 'short', day: 'numeric', month: 'short' });
    var today = new Date();
    var todayStart = new Date(today.getFullYear(), today.getMonth(), today.getDate());
    var minCalendarMonth = new Date(todayStart.getFullYear(), todayStart.getMonth(), 1);
    var maxAvailabilityDate = addMonths(todayStart, 3);
    var maxCalendarMonth = new Date(maxAvailabilityDate.getFullYear(), maxAvailabilityDate.getMonth(), 1);

    var calendarMonth = new Date(today.getFullYear(), today.getMonth(), 1);
    var selectedCategoryIndex = 0;
    var doctorMode = 'auto';
    var selectedService = null;
    var selectedDoctor = null;
    var selectedDate = null;
    var selectedTime = null;

    function formatPrice(value) {
      return 'MX$' + Number(value).toFixed(2);
    }

    function computeEndTime(startTime, durationSeconds) {
      var parts = startTime.split(':');
      var h = parseInt(parts[0], 10);
      var m = parseInt(parts[1] || '0', 10);
      var totalMinutes = h * 60 + m + Math.round(durationSeconds / 60);
      var eh = Math.floor(totalMinutes / 60) % 24;
      var em = totalMinutes % 60;
      return (eh < 10 ? '0' : '') + eh + ':' + (em < 10 ? '0' : '') + em;
    }

    function formatTimeRange(startTime) {
      if (!selectedService || !selectedService.duration) return startTime;
      var endTime = computeEndTime(startTime, selectedService.duration);
      return startTime + ' - ' + endTime;
    }

    function isSameDate(a, b) {
      return a && b &&
        a.getFullYear() === b.getFullYear() &&
        a.getMonth() === b.getMonth() &&
        a.getDate() === b.getDate();
    }

    function addMonths(date, months) {
      var result = new Date(date.getTime());
      var originalDay = result.getDate();
      result.setMonth(result.getMonth() + months);
      if (result.getDate() !== originalDay) {
        result.setDate(0);
      }
      return new Date(result.getFullYear(), result.getMonth(), result.getDate());
    }

    function isBeforeMonth(a, b) {
      return a.getFullYear() < b.getFullYear() ||
        (a.getFullYear() === b.getFullYear() && a.getMonth() < b.getMonth());
    }

    function isAfterMonth(a, b) {
      return a.getFullYear() > b.getFullYear() ||
        (a.getFullYear() === b.getFullYear() && a.getMonth() > b.getMonth());
    }

    function clampCalendarMonth() {
      if (isBeforeMonth(calendarMonth, minCalendarMonth)) {
        calendarMonth = new Date(minCalendarMonth);
      } else if (isAfterMonth(calendarMonth, maxCalendarMonth)) {
        calendarMonth = new Date(maxCalendarMonth);
      }
    }

    function initializeDefaults() {
      selectedService = null;
      selectedDate = null;
      selectedTime = null;
      selectedDoctor = null;
    }

    function hasAllSelections() {
      var hasDoctorSelection = doctorMode !== 'manual' || !!selectedDoctor;
      return !!selectedService && !!selectedDate && !!selectedTime && hasDoctorSelection;
    }

    function updateIntakeSummary() {
      var svcEl = document.getElementById('vmSummaryService');
      var dateEl = document.getElementById('vmSummaryDate');
      var docEl = document.getElementById('vmSummaryDoctor');
      if (!svcEl || !dateEl || !docEl) return;

      // Consulta
      if (selectedService) {
        svcEl.textContent = selectedService.category + ' — ' + selectedService.type + ' (' + formatPrice(selectedService.price) + ')';
      } else {
        svcEl.textContent = '—';
      }

      // Día/hora
      if (selectedDate && selectedTime) {
        var dayFormatted = new Intl.DateTimeFormat('es-MX', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' }).format(selectedDate);
        dateEl.textContent = dayFormatted.charAt(0).toUpperCase() + dayFormatted.slice(1) + ' · ' + formatTimeRange(selectedTime) + ' hrs';
      } else {
        dateEl.textContent = '—';
      }

      // Doctor
      if (selectedDoctor && selectedDoctor.name) {
        docEl.textContent = selectedDoctor.name;
      } else {
        docEl.textContent = 'Por asignar';
      }
    }


    function showIntakeStep() {
      if (!bookingStage || !formStage) {
        return;
      }
      closeAllFields(null);
      updateIntakeSummary();

      // Slide-out booking stage
      heroStages.classList.add('is-animating');
      bookingStage.classList.add('is-sliding-out');

      function onBookingSlideOutEnd() {
        bookingStage.removeEventListener('animationend', onBookingSlideOutEnd);
        bookingStage.classList.remove('is-sliding-out');
        bookingStage.classList.add('is-hidden');
        bookingStage.setAttribute('aria-hidden', 'true');

        // Slide-in form stage
        formStage.classList.remove('is-hidden');
        formStage.classList.add('is-active');
        formStage.classList.add('is-sliding-in');
        formStage.setAttribute('aria-hidden', 'false');

        function onFormSlideInEnd() {
          formStage.removeEventListener('animationend', onFormSlideInEnd);
          formStage.classList.remove('is-sliding-in');
          heroStages.classList.remove('is-animating');
        }
        formStage.addEventListener('animationend', onFormSlideInEnd);
      }
      bookingStage.addEventListener('animationend', onBookingSlideOutEnd);
    }

    function showBookingStep() {
      if (!bookingStage || !formStage) {
        return;
      }

      // Slide-out form stage
      heroStages.classList.add('is-animating');
      formStage.classList.add('is-sliding-out');

      function onFormSlideOutEnd() {
        formStage.removeEventListener('animationend', onFormSlideOutEnd);
        formStage.classList.remove('is-sliding-out');
        formStage.classList.remove('is-active');
        formStage.classList.add('is-hidden');
        formStage.setAttribute('aria-hidden', 'true');

        // Slide-in booking stage
        bookingStage.classList.remove('is-hidden');
        bookingStage.classList.add('is-sliding-in');
        bookingStage.setAttribute('aria-hidden', 'false');

        function onBookingSlideInEnd() {
          bookingStage.removeEventListener('animationend', onBookingSlideInEnd);
          bookingStage.classList.remove('is-sliding-in');
          heroStages.classList.remove('is-animating');
        }
        bookingStage.addEventListener('animationend', onBookingSlideInEnd);
      }
      formStage.addEventListener('animationend', onFormSlideOutEnd);
    }

    function showSuccessStep() {
      if (!formStage || !successStage) return;
      heroStages.classList.add('is-animating');
      formStage.classList.add('is-sliding-out');

      function onFormOutEnd() {
        formStage.removeEventListener('animationend', onFormOutEnd);
        formStage.classList.remove('is-sliding-out');
        formStage.classList.remove('is-active');
        formStage.classList.add('is-hidden');
        formStage.setAttribute('aria-hidden', 'true');

        successStage.classList.add('is-active');
        successStage.classList.add('is-sliding-in');
        successStage.setAttribute('aria-hidden', 'false');

        function onSuccessInEnd() {
          successStage.removeEventListener('animationend', onSuccessInEnd);
          successStage.classList.remove('is-sliding-in');
          heroStages.classList.remove('is-animating');
        }
        successStage.addEventListener('animationend', onSuccessInEnd);
      }
      formStage.addEventListener('animationend', onFormOutEnd);
    }

    // --- TRANSICIONES PARA STAGE DE PAGO ---

    function showPaymentStep() {
      if (!formStage || !paymentStage) return;
      heroStages.classList.add('is-animating');
      formStage.classList.add('is-sliding-out');

      function onFormOutEnd() {
        formStage.removeEventListener('animationend', onFormOutEnd);
        formStage.classList.remove('is-sliding-out');
        formStage.classList.remove('is-active');
        formStage.classList.add('is-hidden');
        formStage.setAttribute('aria-hidden', 'true');

        paymentStage.classList.remove('is-hidden');
        paymentStage.classList.add('is-active');
        paymentStage.classList.add('is-sliding-in');
        paymentStage.setAttribute('aria-hidden', 'false');

        function onPaymentInEnd() {
          paymentStage.removeEventListener('animationend', onPaymentInEnd);
          paymentStage.classList.remove('is-sliding-in');
          heroStages.classList.remove('is-animating');
        }
        paymentStage.addEventListener('animationend', onPaymentInEnd);
      }
      formStage.addEventListener('animationend', onFormOutEnd);
    }

    function showFormFromPayment() {
      if (!paymentStage || !formStage) return;
      // Destruir Stripe Checkout si existe
      if (stripeCheckoutInstance) {
        stripeCheckoutInstance.destroy();
        stripeCheckoutInstance = null;
      }
      heroStages.classList.add('is-animating');
      paymentStage.classList.add('is-sliding-out');

      function onPaymentOutEnd() {
        paymentStage.removeEventListener('animationend', onPaymentOutEnd);
        paymentStage.classList.remove('is-sliding-out');
        paymentStage.classList.remove('is-active');
        paymentStage.classList.add('is-hidden');
        paymentStage.setAttribute('aria-hidden', 'true');

        formStage.classList.remove('is-hidden');
        formStage.classList.add('is-active');
        formStage.classList.add('is-sliding-in');
        formStage.setAttribute('aria-hidden', 'false');

        function onFormInEnd() {
          formStage.removeEventListener('animationend', onFormInEnd);
          formStage.classList.remove('is-sliding-in');
          heroStages.classList.remove('is-animating');
        }
        formStage.addEventListener('animationend', onFormInEnd);
      }
      paymentStage.addEventListener('animationend', onPaymentOutEnd);
    }

    function showSuccessFromPayment() {
      if (!paymentStage || !successStage) return;
      // Destruir Stripe Checkout si existe
      if (stripeCheckoutInstance) {
        stripeCheckoutInstance.destroy();
        stripeCheckoutInstance = null;
      }
      heroStages.classList.add('is-animating');
      paymentStage.classList.add('is-sliding-out');

      function onPaymentOutEnd() {
        paymentStage.removeEventListener('animationend', onPaymentOutEnd);
        paymentStage.classList.remove('is-sliding-out');
        paymentStage.classList.remove('is-active');
        paymentStage.classList.add('is-hidden');
        paymentStage.setAttribute('aria-hidden', 'true');

        successStage.classList.add('is-active');
        successStage.classList.add('is-sliding-in');
        successStage.setAttribute('aria-hidden', 'false');

        function onSuccessInEnd() {
          successStage.removeEventListener('animationend', onSuccessInEnd);
          successStage.classList.remove('is-sliding-in');
          heroStages.classList.remove('is-animating');
        }
        successStage.addEventListener('animationend', onSuccessInEnd);
      }
      paymentStage.addEventListener('animationend', onPaymentOutEnd);
    }

    function updatePaymentSummary() {
      if (paymentSumService && selectedService) {
        paymentSumService.textContent = selectedService.category + ' — ' + selectedService.type;
      }
      if (paymentSumDate && selectedDate && selectedTime) {
        var dayFormatted = new Intl.DateTimeFormat('es-MX', { weekday: 'long', day: 'numeric', month: 'long' }).format(selectedDate);
        paymentSumDate.textContent = dayFormatted.charAt(0).toUpperCase() + dayFormatted.slice(1) + ' · ' + formatTimeRange(selectedTime) + ' hrs';
      }
      if (paymentSumTotal && selectedService) {
        paymentSumTotal.textContent = formatPrice(selectedService.price) + ' MXN';
      }
    }

    function initStripeCheckout(clientSecret) {
      if (!stripeCheckoutEl) return;

      // Verificar que Stripe.js esté cargado y la config exista
      if (typeof Stripe === 'undefined') {
        console.error('[VM Stripe] Stripe.js no está cargado');
        showStripeError('Stripe.js no pudo cargarse. Recarga la página.');
        return;
      }

      var publicKey = (typeof vmStripeConfig !== 'undefined' && vmStripeConfig.publicKey)
        ? vmStripeConfig.publicKey
        : (VMHB_CONFIG.stripePublicKey || '');

      if (!publicKey) {
        console.error('[VM Stripe] No se encontró la clave pública de Stripe');
        showStripeError('Configuración de pago incompleta.');
        return;
      }

      // Inicializar Stripe si no se ha hecho
      if (!stripeInstance) {
        stripeInstance = Stripe(publicKey);
      }

      // Mostrar loading
      if (stripeLoadingEl) stripeLoadingEl.style.display = 'flex';
      if (stripeErrorEl) stripeErrorEl.classList.remove('is-visible');
      stripeCheckoutEl.innerHTML = '';

      stripeInstance.createEmbeddedCheckoutPage({
        clientSecret: clientSecret,
      }).then(function (checkout) {
        stripeCheckoutInstance = checkout;
        // Ocultar loading y montar
        if (stripeLoadingEl) stripeLoadingEl.style.display = 'none';
        checkout.mount('#vmStripeCheckout');
      }).catch(function (err) {
        console.error('[VM Stripe] Error al inicializar checkout:', err);
        showStripeError('Error al cargar el formulario de pago.');
      });
    }

    function showStripeError(msg) {
      if (stripeLoadingEl) stripeLoadingEl.style.display = 'none';
      if (stripeErrorEl) {
        stripeErrorEl.innerHTML = msg + '<br><button type="button" class="vm-speed-intake__back" onclick="location.reload()" style="margin-top:1rem;">Reintentar</button>';
        stripeErrorEl.classList.add('is-visible');
      }
    }

    // === PAYPAL ===
    var paypalWrap = document.getElementById('vmPayPalWrap');
    var paypalLoadingEl = document.getElementById('vmPayPalLoading');
    var paypalErrorEl = document.getElementById('vmPayPalError');
    var paypalButtonsEl = document.getElementById('vmPayPalButtons');
    var paypalRendered = false;
    var stripeWrap = document.getElementById('vmStripeWrap');
    var payMethodStripeBtn = document.getElementById('vmPayMethodStripe');
    var payMethodPayPalBtn = document.getElementById('vmPayMethodPayPal');

    // Payment method switcher
    function switchPaymentMethod(method) {
      if (method === 'stripe') {
        if (stripeWrap) stripeWrap.style.display = '';
        if (paypalWrap) paypalWrap.classList.remove('is-active');
        if (payMethodStripeBtn) payMethodStripeBtn.classList.add('is-active');
        if (payMethodPayPalBtn) payMethodPayPalBtn.classList.remove('is-active');
      } else {
        if (stripeWrap) stripeWrap.style.display = 'none';
        if (paypalWrap) paypalWrap.classList.add('is-active');
        if (payMethodStripeBtn) payMethodStripeBtn.classList.remove('is-active');
        if (payMethodPayPalBtn) payMethodPayPalBtn.classList.add('is-active');
        if (!paypalRendered) {
          renderPayPalButtons();
        }
      }
    }

    if (payMethodStripeBtn) {
      payMethodStripeBtn.addEventListener('click', function() { switchPaymentMethod('stripe'); });
    }
    if (payMethodPayPalBtn) {
      payMethodPayPalBtn.addEventListener('click', function() { switchPaymentMethod('paypal'); });
    }

    function renderPayPalButtons() {
      if (typeof paypal === 'undefined') {
        if (paypalErrorEl) {
          paypalErrorEl.textContent = 'PayPal SDK no se pudo cargar. Recarga la página.';
          paypalErrorEl.classList.add('is-visible');
        }
        return;
      }

      paypalRendered = true;
      if (paypalLoadingEl) paypalLoadingEl.classList.add('is-visible');

      paypal.Buttons({
        style: {
          layout: 'vertical',
          color: 'gold',
          shape: 'pill',
          label: 'paypal',
          height: 48
        },
        createOrder: function() {
          var serviceName = selectedService
            ? selectedService.category + ' - ' + selectedService.type
            : 'Consulta VirtualMD';
          var servicePrice = selectedService ? selectedService.price : 0;

          var createUrl = VM_AJAX_URL + (VM_AJAX_URL.indexOf('?') !== -1 ? '&' : '?') + 'action=' + vmhbAction('paypalCreateOrder', 'vm_paypal_create_order');

          return fetch(createUrl, {
            method: 'POST',
            body: JSON.stringify({
              serviceName: serviceName,
              servicePrice: servicePrice,
              bookingData: pendingBookingPayload || {},
              doctorMode: doctorMode
            }),
            headers: { 'Content-Type': 'application/json' }
          })
          .then(function(res) { return res.json(); })
          .then(function(res) {
            if (res.success && res.data && res.data.orderID) {
              return res.data.orderID;
            }
            var msg = (res.data && res.data.message) ? res.data.message : 'Error al crear orden PayPal';
            throw new Error(msg);
          });
        },
        onApprove: function(data) {
          if (paypalLoadingEl) {
            paypalLoadingEl.classList.add('is-visible');
            paypalLoadingEl.querySelector('.vm-speed-spinner') && (paypalLoadingEl.querySelector('.vm-speed-spinner').style.display = '');
          }
          if (paypalButtonsEl) paypalButtonsEl.style.display = 'none';

          var captureUrl = VM_AJAX_URL + (VM_AJAX_URL.indexOf('?') !== -1 ? '&' : '?') + 'action=' + vmhbAction('paypalCaptureOrder', 'vm_paypal_capture_order');

          return fetch(captureUrl, {
            method: 'POST',
            body: JSON.stringify({
              orderID: data.orderID,
              bookingData: pendingBookingPayload || {},
              doctorMode: doctorMode
            }),
            headers: { 'Content-Type': 'application/json' }
          })
          .then(function(res) { return res.json(); })
          .then(function(res) {
            if (paypalLoadingEl) paypalLoadingEl.classList.remove('is-visible');

            if (res.success && res.data && res.data.status === 'COMPLETED') {
              // Pago exitoso; la consulta se registra en Amelia en segundo plano.
              showSuccessFromPayment();
            } else {
              var msg = (res.data && res.data.message) ? res.data.message : 'El pago no se completó';
              var paymentCompleted = !!(res.data && res.data.payment_completed);
              if (paymentCompleted) {
                var technicalDetail = (res.data.booking_result && res.data.booking_result.message)
                  ? res.data.booking_result.message
                  : msg;
                msg = 'Tu pago fue aprobado, pero no pudimos registrar la consulta automáticamente. Detalle: ' + technicalDetail + '. Escríbenos para completar el agendamiento con tu comprobante PayPal.';
                console.error('[VM PayPal] Amelia booking failed after completed payment:', JSON.stringify(res.data));
              }
              if (paypalErrorEl) {
                paypalErrorEl.textContent = msg;
                paypalErrorEl.classList.add('is-visible');
              }
              if (!paymentCompleted && paypalButtonsEl) paypalButtonsEl.style.display = '';
            }
          })
          .catch(function(err) {
            if (paypalLoadingEl) paypalLoadingEl.classList.remove('is-visible');
            if (paypalErrorEl) {
              paypalErrorEl.textContent = 'Error de conexión: ' + err.message;
              paypalErrorEl.classList.add('is-visible');
            }
            if (paypalButtonsEl) paypalButtonsEl.style.display = '';
          });
        },
        onError: function(err) {
          console.error('[VM PayPal] Error:', err);
          if (paypalErrorEl) {
            paypalErrorEl.textContent = 'Ocurrió un error con PayPal. Intenta de nuevo.';
            paypalErrorEl.classList.add('is-visible');
          }
        },
        onCancel: function() {
          // El usuario canceló el flujo de PayPal, no hacemos nada
        }
      }).render('#vmPayPalButtons').then(function() {
        if (paypalLoadingEl) paypalLoadingEl.classList.remove('is-visible');
      });
    }

    function verifyStripePayment(sessionId) {
      var verifyUrl = VM_AJAX_URL + (VM_AJAX_URL.indexOf('?') !== -1 ? '&' : '?') + 'action=' + vmhbAction('stripeVerifyPayment', 'vm_stripe_verify_payment');

      return fetch(verifyUrl, {
        method: 'POST',
        body: JSON.stringify({ session_id: sessionId }),
        headers: { 'Content-Type': 'application/json' }
      })
        .then(function (res) { return res.json(); })
        .then(function (res) {
          if (res.success && res.data && res.data.status === 'complete') {
            return { success: true, data: res.data };
          }
          return { success: false, data: res.data || {} };
        })
        .catch(function (err) {
          console.error('[VM Stripe] Verify error:', err);
          return { success: false, error: err.message };
        });
    }

    function updateSpecialtyValue() {
      if (!selectedService) {
        specialtyValue.textContent = 'Elige categoría, consulta y precio';
        return;
      }
      specialtyValue.textContent = selectedService.category + ' · ' + selectedService.type + ' · ' + formatPrice(selectedService.price);
    }

    function updateDateValue() {
      if (!selectedDate || !selectedTime) {
        dateValue.textContent = 'Selecciona día y horario';
        return;
      }
      dateValue.textContent = shortDateFormatter.format(selectedDate).replace('.', '') + ' · ' + formatTimeRange(selectedTime);
    }

    function updateDoctorValue() {
      if (!doctorValue) {
        return;
      }
      if (doctorMode !== 'manual') {
        doctorValue.textContent = 'Asignación automática';
        return;
      }
      if (!selectedDoctor) {
        doctorValue.textContent = 'Selecciona un doctor';
        return;
      }
      doctorValue.textContent = selectedDoctor.name;
    }

    function setDoctorMode(mode) {
      doctorMode = mode === 'manual' ? 'manual' : 'auto';

      if (doctorModeButtons.length) {
        doctorModeButtons.forEach(function (button) {
          var isActive = button.dataset.doctorMode === doctorMode;
          button.classList.toggle('is-active', isActive);
          button.setAttribute('aria-pressed', isActive ? 'true' : 'false');
        });
      }

      bookingWidget.classList.toggle('is-manual', doctorMode === 'manual');

      if (doctorMode !== 'manual') {
        selectedDoctor = null;
        closeField(doctorField, doctorPopover, doctorToggle);
        // Recargar slots sin filtro de doctor
        if (selectedService) {
          loadSlotsForMonth();
        }
      } else {
        // Cargar doctores desde API filtrados por servicio
        if (selectedService) {
          loadDoctors(selectedService.id);
        } else {
          renderDoctorList();
        }
      }

      updateDoctorValue();
    }

    function openField(field, popover, toggle) {
      if (!field || !popover || !toggle) return;
      closeAllFields(field);
      popover.hidden = false;
      requestAnimationFrame(function () {
        field.classList.add('is-open');
        toggle.setAttribute('aria-expanded', 'true');
      });
    }

    function closeField(field, popover, toggle) {
      if (!field || !popover || !toggle) return;
      field.classList.remove('is-open');
      toggle.setAttribute('aria-expanded', 'false');
      setTimeout(function () {
        if (!field.classList.contains('is-open')) {
          popover.hidden = true;
        }
      }, 220);
    }

    function closeAllFields(exceptField) {
      if (exceptField !== specialtyField) {
        closeField(specialtyField, specialtyPopover, specialtyToggle);
        showMobileCategories();
      }
      if (exceptField !== doctorField) {
        closeField(doctorField, doctorPopover, doctorToggle);
      }
      if (exceptField !== dateField) {
        closeField(dateField, datePopover, dateToggle);
      }
    }

    function renderCategories() {
      categoryList.innerHTML = '';
      var q = specialtySearch ? specialtySearch.value.trim().toLowerCase() : '';

      var visibleCategories = [];
      specialtyData.forEach(function (category, index) {
        if (!q) {
          visibleCategories.push(index);
          return;
        }
        var catMatch = category.category.toLowerCase().indexOf(q) > -1;
        var svcMatch = category.services.some(function (s) { return s.type.toLowerCase().indexOf(q) > -1; });
        if (catMatch || svcMatch) {
          visibleCategories.push(index);
        }
      });

      if (visibleCategories.length > 0 && visibleCategories.indexOf(selectedCategoryIndex) === -1) {
        selectedCategoryIndex = visibleCategories[0];
      }

      specialtyData.forEach(function (category, index) {
        if (visibleCategories.indexOf(index) === -1) return;

        var matchingCount = category.services.length;
        if (q) {
          var matchingServices = category.services.filter(function (s) {
            return s.type.toLowerCase().indexOf(q) > -1 || category.category.toLowerCase().indexOf(q) > -1;
          });
          matchingCount = matchingServices.length;
        }

        var btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'vm-speed-category-item' + (index === selectedCategoryIndex ? ' is-active' : '');
        btn.innerHTML = '<span>' + category.category + '</span><span class="vm-speed-category-count">(' + matchingCount + ')</span>';
        btn.addEventListener('click', function () {
          selectedCategoryIndex = index;
          renderCategories();
          renderServices();
          if (isMobileView()) {
            showMobileServices();
          }
        });
        categoryList.appendChild(btn);
      });

      if (visibleCategories.length === 0) {
        categoryList.innerHTML = '<div style="padding:1rem;color:#7a86a2;font-size:0.9rem;">Sin resultados</div>';
      }
    }

    function renderServices() {
      var currentCategory = specialtyData[selectedCategoryIndex];
      serviceList.innerHTML = '';
      if (!currentCategory || !currentCategory.services) return;

      // Mobile: add back button
      if (isMobileView()) {
        var backBtn = document.createElement('button');
        backBtn.type = 'button';
        backBtn.className = 'vm-speed-service-back';
        backBtn.innerHTML = '← ' + currentCategory.category;
        backBtn.addEventListener('click', function () {
          showMobileCategories();
        });
        serviceList.appendChild(backBtn);
      }

      var q = specialtySearch ? specialtySearch.value.trim().toLowerCase() : '';
      var hasResults = false;

      currentCategory.services.forEach(function (service) {
        if (q) {
          var catMatch = currentCategory.category.toLowerCase().indexOf(q) > -1;
          var svcMatch = service.type.toLowerCase().indexOf(q) > -1;
          if (!catMatch && !svcMatch) return; // Salta este servicio si no coincide
        }

        hasResults = true;
        var full = {
          id: service.id,
          categoryId: currentCategory.categoryId,
          category: currentCategory.category,
          type: service.type,
          mode: service.mode,
          price: service.price,
          duration: service.duration || 3600
        };
        var active = selectedService &&
          selectedService.category === full.category &&
          selectedService.type === full.type &&
          selectedService.id === full.id;
        var btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'vm-speed-service-item' + (active ? ' is-active' : '');
        btn.innerHTML =
          '<span class="vm-speed-service-title">' + full.type + '</span>' +
          '<span class="vm-speed-service-meta"><span>' + full.mode + '</span><span class="vm-speed-service-price">' + formatPrice(full.price) + '</span></span>';
        btn.addEventListener('click', function () {
          var serviceChanged = !selectedService || selectedService.id !== full.id;
          selectedService = full;
          updateSpecialtyValue();
          renderServices();
          // Al cambiar servicio, recargar doctores y slots
          if (serviceChanged) {
            selectedDate = null;
            selectedTime = null;
            slotsData = {};
            occupiedData = {};
            providerMapData = {};
            slotsPayloadLoaded = false;
            updateDateValue();
            if (doctorMode === 'manual') {
              loadDoctors(full.id);
              // Auto-abrir el dropdown de doctor
              if (doctorField && doctorPopover && doctorToggle) {
                openField(doctorField, doctorPopover, doctorToggle);
              }
            } else {
              loadDoctors(full.id);
              loadSlotsForMonth();
              // Auto-abrir el popover de fecha (muestra skeleton mientras carga)
              openField(dateField, datePopover, dateToggle);
            }
          }
          closeField(specialtyField, specialtyPopover, specialtyToggle);
        });
        serviceList.appendChild(btn);
      });

      if (q && !hasResults) {
        serviceList.innerHTML = '<div style="padding:1rem;text-align:center;color:#7a86a2;font-size:0.95rem;">No se encontraron servicios</div>';
      }
    }

    function renderDoctorList() {
      if (!doctorList) {
        return;
      }

      doctorList.innerHTML = '';

      if (isLoadingDoctors) {
        doctorList.innerHTML = '<div style="padding:1rem;text-align:center;color:#7a86a2;font-size:0.95rem;">Cargando doctores…</div>';
        return;
      }

      if (!doctorData.length) {
        doctorList.innerHTML = '<div style="padding:1rem;text-align:center;color:#7a86a2;font-size:0.95rem;">No hay doctores disponibles para esta especialidad</div>';
        return;
      }

      var q = doctorSearch ? doctorSearch.value.trim().toLowerCase() : '';
      var hasResults = false;

      doctorData.forEach(function (doctor) {
        if (q && doctor.name.toLowerCase().indexOf(q) === -1) {
          return; // Salta si no coincide
        }
        hasResults = true;
        var active = selectedDoctor && selectedDoctor.id === doctor.id;
        var btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'vm-speed-doctor-item' + (active ? ' is-active' : '');
        btn.innerHTML =
          '<span class="vm-speed-doctor-name">' + doctor.name + '</span>' +
          '<span class="vm-speed-doctor-meta">' + doctor.meta + '</span>';
        btn.addEventListener('click', function () {
          var doctorChanged = !selectedDoctor || selectedDoctor.id !== doctor.id;
          selectedDoctor = doctor;
          updateDoctorValue();
          renderDoctorList();
          closeField(doctorField, doctorPopover, doctorToggle);
          // Recargar slots con el doctor seleccionado
          if (doctorChanged && selectedService) {
            selectedDate = null;
            selectedTime = null;
            slotsData = {};
            occupiedData = {};
            providerMapData = {};
            slotsPayloadLoaded = false;
            updateDateValue();
            loadSlotsForMonth();
            // Auto-abrir el popover de fecha (muestra skeleton mientras carga)
            openField(dateField, datePopover, dateToggle);
          }
        });
        doctorList.appendChild(btn);
      });

      if (q && !hasResults) {
        doctorList.innerHTML = '<div style="padding:1rem;text-align:center;color:#7a86a2;font-size:0.95rem;">No se encontraron doctores</div>';
      }
    }

    function renderWeekdays() {
      weekdays.innerHTML = '';
      weekLabels.forEach(function (label) {
        var div = document.createElement('div');
        div.className = 'vm-speed-weekday';
        div.textContent = label;
        weekdays.appendChild(div);
      });
    }

    function formatDateKey(d) {
      var y = d.getFullYear();
      var m = String(d.getMonth() + 1).padStart(2, '0');
      var day = String(d.getDate()).padStart(2, '0');
      return y + '-' + m + '-' + day;
    }

    function renderCalendar() {
      clampCalendarMonth();
      calTitle.textContent = monthFormatter.format(calendarMonth);
      calDays.innerHTML = '';

      if (calPrev) {
        calPrev.disabled = isBeforeMonth(new Date(calendarMonth.getFullYear(), calendarMonth.getMonth() - 1, 1), minCalendarMonth);
      }
      if (calNext) {
        calNext.disabled = isAfterMonth(new Date(calendarMonth.getFullYear(), calendarMonth.getMonth() + 1, 1), maxCalendarMonth);
      }

      // Mostrar skeleton mientras cargan los slots
      if (isLoadingSlots) {
        var html = '';
        for (var sk = 0; sk < 35; sk++) {
          html += '<div class="vm-speed-cal-skeleton"></div>';
        }
        html += '<div style="grid-column:1/-1;text-align:center;color:#7a86a2;padding:0.5rem 0;font-size:0.85rem;">' +
          '<span class="vm-speed-spinner"></span> Cargando disponibilidad…</div>';
        calDays.innerHTML = html;
        return;
      }

      var start = new Date(calendarMonth.getFullYear(), calendarMonth.getMonth(), 1);
      var end = new Date(calendarMonth.getFullYear(), calendarMonth.getMonth() + 1, 0);
      var startDay = (start.getDay() + 6) % 7;

      for (var i = 0; i < startDay; i++) {
        var empty = document.createElement('div');
        calDays.appendChild(empty);
      }

      for (var day = 1; day <= end.getDate(); day++) {
        var current = new Date(calendarMonth.getFullYear(), calendarMonth.getMonth(), day);
        var dateKey = formatDateKey(current);
        var hasSlots = slotsData[dateKey] && slotsData[dateKey].length > 0;
        var btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'vm-speed-day';
        btn.textContent = String(day);
        if (isSameDate(current, selectedDate)) {
          btn.classList.add('is-active');
        }

        var isPast = current < todayStart;
        var isAfterWindow = current > maxAvailabilityDate;
        var hasLoadedSlots = selectedService && slotsPayloadLoaded;
        var hasSlots = slotsData[dateKey] && slotsData[dateKey].length > 0;
        var noAvail = hasLoadedSlots && !hasSlots;

        if (isPast || isAfterWindow) {
          btn.disabled = true;
        } else if (noAvail) {
          // Si ya cargaron los datos y este día no tiene slots disponibles (ya sea porque no atiende o porque está lleno)
          btn.disabled = true;
          btn.classList.add('is-unavailable');
        } else if (hasLoadedSlots && hasSlots) {
          btn.classList.add('is-available');
        }

        if (!isPast && !isAfterWindow && !btn.disabled) {
          btn.addEventListener('click', function (selectedDay) {
            return function () {
              selectedDate = selectedDay;
              selectedTime = null;
              renderCalendar();
              renderTimes();
              updateDateValue();
            };
          }(current));
        }
        calDays.appendChild(btn);
      }
    }

    function renderTimes() {
      timeList.innerHTML = '';

      if (isLoadingSlots) {
        timeList.innerHTML = '<div style="grid-column:1/-1;text-align:center;color:#7a86a2;padding:0.8rem;font-size:0.9rem;"><span class="vm-speed-spinner"></span> Cargando horarios\u2026</div>';
        return;
      }

      if (!selectedDate) {
        timeList.innerHTML = '<div style="grid-column:1/-1;text-align:center;color:#7a86a2;padding:0.8rem;font-size:0.9rem;">Selecciona un día primero</div>';
        return;
      }

      var dateKey = formatDateKey(selectedDate);
      var availableTimes = slotsData[dateKey] || [];

      if (!availableTimes.length) {
        timeList.innerHTML = '<div style="grid-column:1/-1;text-align:center;color:#7a86a2;padding:0.8rem;font-size:0.9rem;">No hay horarios disponibles este día</div>';
        return;
      }

      availableTimes.forEach(function (time) {
        var btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'vm-speed-time-item is-available' + (selectedTime === time ? ' is-active' : '');
        btn.textContent = formatTimeRange(time);
        btn.addEventListener('click', function () {
          selectedTime = time;
          renderTimes();
          updateDateValue();

          // Auto-assign doctor if in auto mode
          if (doctorMode !== 'manual' && providerMapData && selectedDate) {
            var dk = formatDateKey(selectedDate);
            var providers = providerMapData[dk] && providerMapData[dk][time];
            if (providers && providers.length > 0) {
              // Pick random provider if multiple
              var pickedId = providers[Math.floor(Math.random() * providers.length)];
              // Find doctor info from doctorData (if loaded) or set minimal info
              var found = null;
              for (var i = 0; i < doctorData.length; i++) {
                if (doctorData[i].id === pickedId) { found = doctorData[i]; break; }
              }
              if (found) {
                selectedDoctor = found;
              } else {
                selectedDoctor = { id: pickedId, name: 'Doctor #' + pickedId };
              }
              console.log('[VM Booking] Auto-assigned doctor:', selectedDoctor.id, selectedDoctor.name, '(from', providers.length, 'available)');
              // Mostrar doctor asignado en el toggle
              if (doctorValue) {
                doctorValue.textContent = selectedDoctor.name;
              }
            }
          }

          if (selectedDate) {
            closeField(dateField, datePopover, dateToggle);
          }
        });
        timeList.appendChild(btn);
      });
    }

    specialtyToggle.addEventListener('click', function () {
      var isOpen = specialtyField.classList.contains('is-open');
      if (isOpen) {
        closeField(specialtyField, specialtyPopover, specialtyToggle);
      } else {
        openField(specialtyField, specialtyPopover, specialtyToggle);
        if (specialtySearch) {
          setTimeout(function () { specialtySearch.focus(); }, 100);
        }
      }
    });

    if (specialtySearch) {
      specialtySearch.addEventListener('input', function () {
        renderCategories();
        renderServices();
      });
    }

    if (doctorSearch) {
      doctorSearch.addEventListener('input', function () {
        renderDoctorList();
      });
    }

    if (doctorToggle && doctorField && doctorPopover) {
      doctorToggle.addEventListener('click', function () {
        if (doctorMode !== 'manual') {
          return;
        }
        if (!selectedService) {
          alert('Por favor, selecciona una especialidad y servicio primero.');
          openField(specialtyField, specialtyPopover, specialtyToggle);
          return;
        }
        var isOpen = doctorField.classList.contains('is-open');
        if (isOpen) {
          closeField(doctorField, doctorPopover, doctorToggle);
        } else {
          openField(doctorField, doctorPopover, doctorToggle);
          if (doctorSearch) {
            setTimeout(function () { doctorSearch.focus(); }, 100);
          }
        }
      });
    }

    if (doctorModeButtons.length) {
      doctorModeButtons.forEach(function (button) {
        button.addEventListener('click', function () {
          setDoctorMode(button.dataset.doctorMode);
        });
      });
    }

    dateToggle.addEventListener('click', function () {
      if (!selectedService) {
        alert('Por favor, selecciona una especialidad primero.');
        openField(specialtyField, specialtyPopover, specialtyToggle);
        return;
      }
      if (doctorMode === 'manual' && !selectedDoctor) {
        alert('Por favor, selecciona un doctor primero.');
        openField(doctorField, doctorPopover, doctorToggle);
        return;
      }

      var isOpen = dateField.classList.contains('is-open');
      if (isOpen) {
        closeField(dateField, datePopover, dateToggle);
      } else {
        openField(dateField, datePopover, dateToggle);
      }
    });

    calPrev.addEventListener('click', function () {
      var prevMonth = new Date(calendarMonth.getFullYear(), calendarMonth.getMonth() - 1, 1);
      if (isBeforeMonth(prevMonth, minCalendarMonth)) {
        return;
      }
      calendarMonth = prevMonth;
      loadSlotsForMonth();
    });

    calNext.addEventListener('click', function () {
      var nextMonth = new Date(calendarMonth.getFullYear(), calendarMonth.getMonth() + 1, 1);
      if (isAfterMonth(nextMonth, maxCalendarMonth)) {
        return;
      }
      calendarMonth = nextMonth;
      loadSlotsForMonth();
    });

    bookingCta.addEventListener('click', function (event) {
      event.preventDefault();
      if (!hasAllSelections()) {
        if (!selectedService) {
          openField(specialtyField, specialtyPopover, specialtyToggle);
          return;
        }
        if (doctorMode === 'manual' && !selectedDoctor) {
          openField(doctorField, doctorPopover, doctorToggle);
          return;
        }
        openField(dateField, datePopover, dateToggle);
        return;
      }
      showIntakeStep();
    });

    if (backToBookingBtn) {
      backToBookingBtn.addEventListener('click', function () {
        showBookingStep();
      });
    }

    // --- Botón "Volver" desde Payment stage ---
    if (backToFormBtn) {
      backToFormBtn.addEventListener('click', function () {
        showFormFromPayment();
      });
    }

    if (submitBookingBtn) {
      submitBookingBtn.addEventListener('click', function (event) {
        event.preventDefault();
        var n = intakeName.value.trim();
        var p = intakePhone.value.trim();
        var e = intakeEmail.value.trim();
        var phoneCountry = getSelectedPhoneCountry();
        var formattedPhone = normalizePhoneForBooking(p, phoneCountry);
        if (!n || !p || !e) {
          alert('Por favor, completa nombre, teléfono y correo electrónico.');
          return;
        }

        if (!formattedPhone) {
          alert('Por favor, escribe un teléfono válido.');
          return;
        }

        if (!isPhoneValidForCountry(p, phoneCountry, formattedPhone)) {
          alert('Por favor, revisa el número de teléfono para la lada seleccionada.');
          return;
        }

        if (!selectedDate || !selectedTime || !selectedService) {
          alert('Faltan datos de la consulta. Regresa y completa la selección.');
          return;
        }

        submitBookingBtn.disabled = true;
        submitBookingBtn.textContent = 'Procesando...';

        // Construir el payload para Amelia (se guardará en metadata de Stripe)
        var dateStr = selectedDate.getFullYear() + '-' +
          String(selectedDate.getMonth() + 1).padStart(2, '0') + '-' +
          String(selectedDate.getDate()).padStart(2, '0');
        var startDateTime = dateStr + ' ' + selectedTime;

        var city = intakeCity ? intakeCity.value.trim() : '';
        var note = intakeMessage ? intakeMessage.value.trim() : '';
        var notesCombined = '';
        if (city) notesCombined += 'Ciudad: ' + city + '\n';
        if (note) notesCombined += 'Mensaje: ' + note;

        var nameParts = n.split(' ');
        var firstName = nameParts.shift();
        var lastName = nameParts.length > 0 ? nameParts.join(' ') : ' ';

        // Payload que se enviará a Amelia DESPUÉS del pago exitoso
        var ameliaPayload = {
          type: 'appointment',
          bookingStart: startDateTime,
          notifyParticipants: 1,
          locationId: 1,
          providerId: selectedDoctor ? selectedDoctor.id : 0,
          serviceId: selectedService ? selectedService.id : 0,
          bookings: [{
            persons: 1,
            duration: selectedService && selectedService.duration ? selectedService.duration : 0,
            customerId: null,
            customer: {
              id: null,
              firstName: firstName,
              lastName: lastName,
              email: e,
              phone: formattedPhone,
              countryPhoneIso: phoneCountry.iso,
              externalId: null
            },
            extras: [],
            customFields: {}
          }],
          payment: {
            gateway: 'onSite',
            currency: 'MXN',
            data: {}
          },
          runInstantPostBookingActions: true
        };

        if (notesCombined) {
          ameliaPayload.internalNotes = notesCombined;
        }

        pendingBookingPayload = ameliaPayload;

        // Crear Stripe Checkout Session
        var serviceName = selectedService.category + ' - ' + selectedService.type;
        var stripePayload = {
          serviceName: serviceName,
          servicePrice: selectedService.price,
          customerEmail: e,
          bookingData: ameliaPayload,
          pageUrl: window.location.href
        };

        var createUrl = VM_AJAX_URL + (VM_AJAX_URL.indexOf('?') !== -1 ? '&' : '?') + 'action=' + vmhbAction('stripeCreateSession', 'vm_stripe_create_session');

        fetch(createUrl, {
          method: 'POST',
          body: JSON.stringify(stripePayload),
          headers: { 'Content-Type': 'application/json' }
        })
          .then(function (res) { return res.json(); })
          .then(function (res) {
            submitBookingBtn.disabled = false;
            submitBookingBtn.textContent = 'Continuar al pago';

            if (res.success && res.data && res.data.clientSecret) {
              currentSessionId = res.data.sessionId;

              // Actualizar resumen de pago
              updatePaymentSummary();

              // Transicionar al stage de pago
              showPaymentStep();

              // Inicializar Stripe Checkout embebido
              setTimeout(function () {
                initStripeCheckout(res.data.clientSecret);
              }, 500);
            } else {
              console.error('[VM Stripe] Session error:', res);
              var errMsg = (res.data && res.data.message) ? res.data.message : 'Error al crear la sesión de pago.';
              alert(errMsg);
            }
          })
          .catch(function (err) {
            console.error('[VM Stripe] Fetch error:', err);
            submitBookingBtn.disabled = false;
            submitBookingBtn.textContent = 'Continuar al pago';
            alert('Ocurrió un error de conexión. Intenta de nuevo.');
          });
      });
    }

    document.addEventListener('click', function (event) {
      var insideAnyField = false;
      if (specialtyField && specialtyField.contains(event.target)) insideAnyField = true;
      if (doctorField && doctorField.contains(event.target)) insideAnyField = true;
      if (dateField && dateField.contains(event.target)) insideAnyField = true;
      if (!insideAnyField) {
        closeAllFields(null);
      }
    });

    [specialtyPopover, doctorPopover, datePopover].forEach(function (popover) {
      if (popover) {
        popover.addEventListener('click', function (event) {
          event.stopPropagation();
        });
      }
    });

    document.addEventListener('keydown', function (event) {
      if (event.key === 'Escape') {
        if (heroStages && heroStages.classList.contains('is-form-active')) {
          showBookingStep();
          return;
        }
        closeAllFields(null);
      }
    });

    // ====== FUNCIONES DE CARGA DESDE API DE AMELIA ======

    function applySlotsPayload(payload) {
      slotsData = payload && payload.slots ? payload.slots : {};
      occupiedData = payload && payload.occupied ? payload.occupied : {};
      providerMapData = payload && payload.providerMap ? payload.providerMap : {};
      slotsPayloadLoaded = !!payload;
    }

    function loadCatalog() {
      isLoadingCatalog = true;
      specialtyValue.textContent = 'Cargando especialidades…';
      categoryList.innerHTML = '<div style="padding:1rem;text-align:center;color:#7a86a2;font-size:0.9rem;">Cargando…</div>';

      fetch(VM_AJAX_URL + '?action=' + vmhbAction('catalog', 'vm_amelia_get_catalog'))
        .then(function (res) { return res.json(); })
        .then(function (json) {
          isLoadingCatalog = false;
          if (json.success && json.data && json.data.length) {
            specialtyData = json.data;
            selectedCategoryIndex = 0;
            renderCategories();
            renderServices();
            updateSpecialtyValue();
          } else {
            categoryList.innerHTML = '<div style="padding:1rem;text-align:center;color:#c44;">No se encontraron especialidades</div>';
            console.warn('[VM Booking] Catalog response:', json);
          }
        })
        .catch(function (err) {
          isLoadingCatalog = false;
          categoryList.innerHTML = '<div style="padding:1rem;text-align:center;color:#c44;">Error al cargar especialidades</div>';
          specialtyValue.textContent = 'Error al cargar, intenta recargar';
          console.error('[VM Booking] Error loading catalog:', err);
        });
    }

    function loadDoctors(serviceId) {
      var cacheKey = String(serviceId || 0);

      isLoadingDoctors = true;
      selectedDoctor = null;
      doctorData = [];
      renderDoctorList();
      updateDoctorValue();

      if (doctorCacheByService[cacheKey]) {
        isLoadingDoctors = false;
        doctorData = doctorCacheByService[cacheKey].slice();
        renderDoctorList();
        return;
      }

      var url = VM_AJAX_URL + '?action=' + vmhbAction('providers', 'vm_amelia_get_providers');
      if (serviceId) {
        url += '&serviceId=' + serviceId;
      }

      var requestId = ++activeDoctorsRequestId;

      fetch(url)
        .then(function (res) { return res.json(); })
        .then(function (json) {
          if (requestId !== activeDoctorsRequestId) {
            return;
          }
          isLoadingDoctors = false;
          if (json.success && json.data) {
            doctorData = json.data;
            doctorCacheByService[cacheKey] = json.data.slice();
          }
          renderDoctorList();
        })
        .catch(function (err) {
          if (requestId !== activeDoctorsRequestId) {
            return;
          }
          isLoadingDoctors = false;
          doctorData = [];
          renderDoctorList();
          console.error('[VM Booking] Error loading doctors:', err);
        });
    }

    function loadSlotsForMonth() {
      clampCalendarMonth();

      if (!selectedService) {
        applySlotsPayload(null);
        renderCalendar();
        renderTimes();
        return;
      }

      if (doctorMode === 'manual' && !selectedDoctor) {
        console.log('[VM Booking] Skipping slot load — waiting for doctor selection');
        applySlotsPayload(null);
        renderCalendar();
        renderTimes();
        return;
      }

      isLoadingSlots = true;
      renderCalendar();
      renderTimes();

      var startDate = new Date(calendarMonth.getFullYear(), calendarMonth.getMonth(), 1);
      var endDate = new Date(calendarMonth.getFullYear(), calendarMonth.getMonth() + 1, 0);

      if (startDate < todayStart) {
        startDate = new Date(todayStart);
      }
      if (endDate > maxAvailabilityDate) {
        endDate = new Date(maxAvailabilityDate);
      }

      var startStr = formatDateKey(startDate);
      var endStr = formatDateKey(endDate);

      var url = VM_AJAX_URL + '?action=' + vmhbAction('slots', 'vm_amelia_get_slots')
        + '&serviceId=' + selectedService.id
        + '&date=' + startStr
        + '&endDate=' + endStr
        + '&duration=' + (selectedService.duration || 0);

      if (doctorMode === 'manual' && selectedDoctor) {
        url += '&providerId=' + selectedDoctor.id;
      }

      var requestKey = [selectedService.id, doctorMode, selectedDoctor ? selectedDoctor.id : 0, startStr, endStr, selectedService.duration || 0].join('|');

      if (slotsCacheByQuery[requestKey]) {
        isLoadingSlots = false;
        applySlotsPayload(slotsCacheByQuery[requestKey]);
        renderCalendar();
        renderTimes();
        return;
      }

      console.log('[VM Booking] Loading slots URL:', url);
      console.log('[VM Booking] Service:', selectedService.id, selectedService.type, 'Duration:', selectedService.duration);
      if (selectedDoctor) console.log('[VM Booking] Doctor:', selectedDoctor.id, selectedDoctor.name);

      var _slotsStart = Date.now();
      var requestId = ++activeSlotsRequestId;
      var fetchOptions = {};

      if (supportsAbortController) {
        if (slotsAbortController) {
          slotsAbortController.abort();
        }
        slotsAbortController = new AbortController();
        fetchOptions.signal = slotsAbortController.signal;
      }

      fetch(url, fetchOptions)
        .then(function (res) { return res.json(); })
        .then(function (json) {
          if (requestId !== activeSlotsRequestId) {
            return;
          }

          var elapsed = ((Date.now() - _slotsStart) / 1000).toFixed(2);
          isLoadingSlots = false;
          console.log('[VM Booking] Slots API response (' + elapsed + 's):', JSON.stringify(json).substring(0, 800));

          if (json.success && json.data) {
            slotsCacheByQuery[requestKey] = json.data;
            applySlotsPayload(json.data);
            var freeCount = Object.keys(slotsData).length;
            var occCount = Object.keys(occupiedData).length;
            console.log('[VM Booking] Free dates:', freeCount, '| Occupied dates:', occCount);
            if (Object.keys(providerMapData).length > 0) {
              console.log('[VM Booking] Auto mode: providerMap received for', Object.keys(providerMapData).length, 'dates');
            }
            if (freeCount > 0) {
              var firstKey = Object.keys(slotsData)[0];
              console.log('[VM Booking] Sample free:', firstKey, '→', slotsData[firstKey]);
            }
          } else {
            applySlotsPayload(null);
            console.warn('[VM Booking] No slots in response. success:', json.success, 'data:', json.data);
          }

          renderCalendar();
          renderTimes();
        })
        .catch(function (err) {
          if (supportsAbortController && err && err.name === 'AbortError') {
            return;
          }

          if (requestId !== activeSlotsRequestId) {
            return;
          }

          isLoadingSlots = false;
          applySlotsPayload(null);
          renderCalendar();
          renderTimes();
          console.error('[VM Booking] Error loading slots:', err);
        });
    }

    // ====== INICIALIZACIÓN ======
    initializeDefaults();
    renderWeekdays();
    renderCalendar();
    renderTimes();
    setDoctorMode('auto');
    updateSpecialtyValue();
    updateDateValue();
    updateIntakeSummary();

    // Cargar datos reales de Amelia
    loadCatalog();
  });
